let connectedGamepadIndex;
let loopID;
let prskey=[];
prskey[16]=false;
document.addEventListener("keydown",(e)=>{prskey[e.keyCode]=true})
document.addEventListener("keyup",(e)=>{prskey[e.keyCode]=false})
addEventListener("gamepadconnected", (e) => {
    console.log("Connected");
    connectedGamepadIndex = e.gamepad.index;
    // loopID = requestAnimationFrame(loop);
});
loopID = requestAnimationFrame(loop);

addEventListener("gamepaddisconnected", (e) => {
    console.log("Disconnected");
    connectedGamepadIndex = null;
    cancelAnimationFrame(loopID);
});
const BUTTON_A_INDEX     = 0;
const BUTTON_B_INDEX     = 1;
const BUTTON_X_INDEX     = 2;
const BUTTON_Y_INDEX     = 3;
const BUTTON_LB_INDEX    = 4;
const BUTTON_RB_INDEX    = 5;
const BUTTON_LT_INDEX    = 6;
const BUTTON_RT_INDEX    = 7;
const BUTTON_BACK_INDEX  = 8;
const BUTTON_START_INDEX = 9;
const BUTTON_L3_INDEX    = 10;
const BUTTON_R3_INDEX    = 11;
const BUTTON_UP_INDEX    = 12;
const BUTTON_DOWN_INDEX  = 13;
const BUTTON_LEFT_INDEX  = 14;
const BUTTON_RIGHT_INDEX = 15;
const BUTTON_HOME_INDEX  = 16;
// ===============================
const AXIS_L_HORIZONTAL_INDEX = 0;
const AXIS_L_VERTICAL_INDEX   = 1;
const AXIS_R_HORIZONTAL_INDEX = 2;
const AXIS_R_VERTICAL_INDEX   = 3;


let scene=0;

const wp=new Image(20,20);
const bltImg=new Image();
wp.src="./wp.png";
const img1=new Image();
img1.src="./bullet/bullet-blue.png";
const img2=new Image();
img2.src="./bullet/bullet-red.png";
let bullet1_len=0;
let bullet2_len=0;
const canvas=document.querySelector("canvas");
function loop(){
    const ctx=canvas.getContext("2d");
    // if(scene%2===0){
    //     let randomV=Math.floor(Math.random()*2)+15;
    //     let randomX=Math.floor(Math.random()*120);
    //     for(let i=0;i<12;i++){
    //         bullet2.push(new Bullet("bullet-red",30*(i+1)+15,210+randomX,50,randomV))
    //     }
    // }
    // if(scene%4===0){
    //     bullet1.push(new Bullet("bullet-blue",Math.floor(Math.random()*3)+210,530,Math.floor(Math.random()*820)-100,Math.floor(Math.random()*5)+8))
    // }
    ctx.clearRect(-200,-200,740,920);
    // GamePad
    controls();


    ctx.drawImage(wp,omae.x/1000,omae.y/1000);


    
    // if(Math.abs(Math.hypot(omae.x-testblt.x,omae.y-testblt.y))<=16000){
    //     console.log("hoge")
    // }
    // ctx.drawImage(img1,testblt.x/1000,testblt.y/1000);


    for(let i=0;i<bullet1.length;i++){
        var idx=bullet1[i];
        idx.move();
        if(Math.abs(Math.hypot(omae.x-idx.x,omae.y-idx.y))<=16000){
            bullet1.splice(i,1);
        }
        ctx.drawImage(img1,idx.x/1000,idx.y/1000);
        idx.age++;
    }

    for(let i=0;i<bullet2.length;i++){
        var idx=bullet2[i];
        ctx.drawImage(img2,idx.x/1000,idx.y/1000);
        idx.move();
        if(Math.abs(Math.hypot(omae.x-idx.x,omae.y-idx.y))<=16000){
            bullet2.splice(i,1);
        }
        idx.age++;
    }

    for(let i=0;i<bullet3.length;i++){
        var idx=bullet3[i];
        ctx.drawImage(img2,idx.x/1000,idx.y/1000);
        idx.move();
        if(Math.abs(Math.hypot(omae.x-idx.x,omae.y-idx.y))<=16000){
            bullet3.splice(i,1);
        }
        idx.age++;
    }
    // scene++;
    // setTimeout(() => {
    //     requestAnimationFrame(loop);
    // }, 15);
}
setInterval(() => {
    for(let i=0;i<bullet1.length;i++){
        var idx=bullet1[i];
        if(idx.x<-100000){
            bullet1.splice(i,1);
        }
    }
    for(let i=0;i<bullet2.length;i++){
        var idx=bullet2[i];
        if(idx.x<-100000||idx.x>640000||idx.y<-100000||idx.y>820000){
            bullet2.splice(i,1);
        }
    }
    for(let i=0;i<bullet3.length;i++){
        var idx=bullet3[i];
        if(idx.x<-100000||idx.x>640000||idx.y<-100000||idx.y>820000){
            bullet3.splice(i,1);
        }
    }
}, 300);
let pattern=[];
setInterval(() => {
    if(scene===0){
        pattern[0]=setInterval(() => {
            bullet1.push(new Bullet("bullet-blue",Math.floor(Math.random()*3)+210,530,Math.floor(Math.random()*820)-300,Math.floor(Math.random()*5)+16))
        }, 30);
        setTimeout(() => {
            pattern[1]=setInterval(() => {
                let randomV=Math.floor(Math.random()*2)+15;
                let randomX=Math.floor(Math.random()*120);
                for(let i=0;i<12;i++){
                    bullet2.push(new Bullet("bullet-red",30*(i+1)+15,210+randomX,50,randomV))
                }
            }, 60);
        }, 60);
    }
    if(scene===10){
        clearInterval(pattern[0])
        clearInterval(pattern[1])
        pattern[3]=setInterval(() => {
            var deg=Math.floor((Math.atan2((100-omae.y/1000),omae.x/1000-200)*180)/Math.PI);
            if(deg<0){
                deg=360+deg;
            }
            bullet3[bullet3.length]=new Bullet("hoge",deg,200,100,10);
        }, 70);
    }
    scene++;
    requestAnimationFrame(loop);
}, 33);
var bullet3=[];
let omae={
    x:282.5*1000,
    y:600*1000
}

function controls(){
    var mx=0;
    var my=0;
    // if(navigator.getGamepads()[0]!==null){
    //     let gamepads = navigator.getGamepads();
    //     let gp = gamepads[connectedGamepadIndex];
    //     let leftAxisHorizontal = Math.trunc(gp.axes[AXIS_L_HORIZONTAL_INDEX]*10)/10;
    //     let leftAxisVertical = Math.trunc(gp.axes[AXIS_L_VERTICAL_INDEX]*10)/10;
    // }
    if(prskey.indexOf(true)===-1){return true}
    if(prskey[37]&&prskey[38]){mx=-4242;my=-4242}else
    if(prskey[38]&&prskey[39]){mx=4242;my=-4242}else
    if(prskey[39]&&prskey[40]){mx=4242;my=4242}else
    if(prskey[40]&&prskey[37]){mx=-4242;my=4242}else
    if(prskey[37]){mx=-6000}else
    if(prskey[38]){my=-6000}else
    if(prskey[39]){mx=6000}else
    if(prskey[40]){my=6000}
        if(omae.x+mx<0){omae.x=0}else
        if(omae.x+mx>525000){omae.x=525000}else{omae.x+=mx*(2-(prskey[16]))}
        if(omae.y+my<0){omae.y=0}else
        if(omae.y+my>705000){omae.y=705000}else{omae.y+=my*(2-(prskey[16]))}


}

class Bullet{
    constructor(name,angle,x,y,v,vx,vy,age){
        this.name=name;
        this.angle=angle;
        this.x=x*1000;
        this.y=y*1000;
        this.v=v*1000;
        this.vx=cos[this.angle];
        this.vy=sin[this.angle];
        this.age=0;
    }
    move(){
        this.x+=this.vx*this.v;
        this.y-=this.vy*this.v;
    }
}
function toRad(n){
    return n/180*Math.PI;
}


let sin=[];
let cos=[];

let bullet1=[];
let bullet2=[];
for(let i=0;i<361;i++){
    sin[i]=Math.sin(toRad(i));
    cos[i]=Math.cos(toRad(i));
}

// var testblt;
// testblt=new Bullet("bullet-red",0,300,500,0);