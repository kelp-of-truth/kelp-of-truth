const touch_effect=document.createElement("div")
touch_effect.id="touch_effect";
document.body.appendChild(touch_effect);
const shadowRoot=touch_effect.attachShadow({mode:"open"})
const customCSS=document.createElement("style");
customCSS.textContent=`

.particle {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 50px;
    height: 50px;
    z-index:9999999;
    /* border: 1px solid #000; */
    pointer-events: none;
    user-select: none;
    -webkit-user-drag: none;
  }
  .particle .pulse {
    pointer-events: none;
    position: absolute;
    top: 25px;
    left: 25px;
    border: 3px solid #00ffff80;
    outline: 2px solid #00ffff;
    box-shadow: 0px 0px 5px #fff;
    height: 0px;
    width: 0px;
    padding: 0px;
    opacity: 1;
    rotate: 0deg;
    transition: padding 400ms ease-out, margin 400ms ease-out,
      opacity 600ms ease-out, rotate 800ms linear;
  }
  .particle .dust {
    pointer-events: none;
    margin-top: 0px;
    margin-left: 0px;
    position: absolute;
    width: 8px;
    height: 8px;
    background-color: #00ffff;
    opacity: 1;
    rotate: 0deg;
    transition: margin 400ms ease-out, opacity 600ms ease-out,
      rotate 800ms ease-in;
  }`
shadowRoot.appendChild(customCSS)

    document.addEventListener("mousedown", (e) => {
        if(e.buttons===1){
        var particle = document.createElement("div");
        particle.classList.add("particle");
        particle.style.left = `${e.clientX - 25}px`;
        particle.style.top = `${e.clientY - 25}px`;
        particle.ariaLabel = 800;
        particle.innerHTML = `
      <div class="pulse"></div>
      <div class="dust" style="left: 21px;top: 21px;" ariaLabel=${Math.floor(
            Math.random() * 72
        )}></div>
      <div class="dust" style="left: 21px;top: 21px;" ariaLabel=${Math.floor(Math.random() * 72) + 72
            }></div>
      <div class="dust" style="left: 21px;top: 21px;" ariaLabel=${Math.floor(Math.random() * 72) + 144
            }></div>
      <div class="dust" style="left: 21px;top: 21px;" ariaLabel=${Math.floor(Math.random() * 72) + 216
            }></div>
      <div class="dust" style="left: 21px;top: 21px;" ariaLabel=${Math.floor(Math.random() * 72) + 288
            }></div>
    `;
        shadowRoot.appendChild(particle);
        setTimeout(() => {
            particle.querySelector(".pulse").style.padding = "15px";
            particle.querySelector(".pulse").style.margin = "-15px";
            particle.querySelector(".pulse").style.opacity = "0";
            // particle.querySelector(".pulse").style.rotate = "90deg";
            for (let idx of particle.querySelectorAll(".dust")) {
                idx.style.rotate = `${idx.getAttribute("ariaLabel")}deg`;
                idx.style.marginLeft = `${Math.cos((idx.getAttribute("ariaLabel") / 180) * Math.PI) * 30
                    }px`;
                idx.style.marginTop = `${-1 * Math.sin((idx.getAttribute("ariaLabel") / 180) * Math.PI) * 30
                    }px`;
                idx.style.opacity = "0";
            }
        }, 1);
    }
    });
setInterval(() => {
    for (let idx of document.querySelector("#touch_effect").shadowRoot.querySelectorAll(".particle")) {
        idx.ariaLabel = idx.ariaLabel - 10;
        if (idx.ariaLabel <= 0) {
            idx.remove();
        }
    }
}, 10);
