chrome.runtime.onMessage.addListener((req,sender,sendResponse) => {
    const ms=navigator.mediaSession.metadata;
    const res={
        title:ms.title,
        artist:ms.artist,
        album:ms.album,
        artwork:ms.artwork
    }
    sendResponse(res);
});