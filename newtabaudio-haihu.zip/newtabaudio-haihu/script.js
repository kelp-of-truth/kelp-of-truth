let sMin;
let sDate;
let bookmarks=[];
let bg_image;
window.addEventListener("load",()=>{
    var date=new Date();
    sMin=date.getMinutes();
    sDate=date.getDate();
    document.querySelector("#date").innerHTML=`${date.getMonth()+1}月${date.getDate()}日&nbsp;${transDay(date.getDay())}曜日`;
    document.querySelector("#clock").innerHTML=`${String(date.getHours()).padStart(2,"0")}:${String(date.getMinutes()).padStart(2,"0")}`;
    chrome.tabs.query({audible:true})
    .then((tabs)=>{
        chrome.tabs.sendMessage(tabs[0].id,{tabId:tabs[0].id},(res)=>{
            document.querySelector(".audio").hidden=false;
            document.querySelector(".artwork img#artwork").src=`${res.artwork[res.artwork.length-1].src}`;
            document.querySelector("#wallpaper").src=`${res.artwork[res.artwork.length-1].src}`;
            document.querySelector(".detail #title").innerHTML=`${res.title}`;
            document.querySelector(".detail #artist").innerHTML=`${res.artist}`;
            document.querySelector(".artwork img#artwork").addEventListener("click",()=>{
                chrome.tabs.update(tabs[0].id, {active:true});
            })
        })
    })
    .catch((err)=>{
        document.querySelector(".audio").hidden=true;
        if(bg_image==undefined){
            document.querySelector("#wallpaper").removeAttribute("src");
        }else{
            document.querySelector("#wallpaper").src=bg_image;
        }
    })
    if(localStorage.getItem("bg-image")!==null){
        bg_image=localStorage.getItem("bg-image");
    }
    if(localStorage.getitem("otherfont")!==null){
        document.body.style.fontFamily
    }
    if(localStorage.getitem("clockfont")!==null){
        document.querySelector("#clock").style.fontFamily=localStorage.getItem("clockfont")
    }
    chrome.bookmarks.getTree(function(bookmark) {
        for(let idx of bookmark[0].children[0].children){
            addLink({
                title:idx.title,
                url:idx.url
            });
        }
    });
})
function addLink(e){
    document.querySelector(".links").innerHTML+=`<div class="app"><a href="${e.url}"><img src="chrome-extension://jgpfnffolpjhcipmnlechclmlmdldnjd/_favicon/?pageUrl=${e.url}&size=256" alt="${e.title}"></a>\n<label>${e.title}</label></div>`;
}
setInterval(() => {
    var date=new Date();
    if(date.getDate()!==sDate){
        document.querySelector("#date").innerHTML=`${date.getMonth()}月${date.getDate()}日&nbsp;${transDay(date.getDay())}日`;
        sDate=date.getDate();
    }
    if(date.getMinutes()!==sMin){
        document.querySelector("#clock").innerHTML=`${String(date.getHours()).padStart(2,"0")}:${String(date.getMinutes()).padStart(2,"0")}`;
        sMin=date.getMinutes();
    }
    chrome.tabs.query({audible:true})
    .then((tabs)=>{
        chrome.tabs.sendMessage(tabs[0].id,{tabId:tabs[0].id},(res)=>{
            document.querySelector(".audio").hidden=false;
            document.querySelector(".artwork img#artwork").src=`${res.artwork[res.artwork.length-1].src}`;
            document.querySelector("#wallpaper").src=`${res.artwork[res.artwork.length-1].src}`;
            document.querySelector(".detail #title").innerHTML=`${res.title}`;
            document.querySelector(".detail #artist").innerHTML=`${res.artist}`;
            document.querySelector(".artwork img#artwork").addEventListener("click",()=>{
                chrome.tabs.update(tabs[0].id, {active:true});
            })
        })
    })
    .catch((err)=>{
        document.querySelector(".audio").hidden=true;
        if(bg_image==undefined){
            document.querySelector("#wallpaper").removeAttribute("src");
        }else{
            document.querySelector("#wallpaper").src=bg_image;
        }
    })
}, 500);

function settings(){
    document.body.style.fontFamily=prompt("日付と時計じゃない所のフォント(語彙力)");
    localStorage.setItem("otherfont",document.body.style.fontFamily)
    document.querySelector("#clock").style.fontFamily=prompt("日付と時計のフォント");
    localStorage.setItem("clockfont",document.querySelector("#clock").style.fontFamily);
    document.querySelector("#defaultwallpaper").hidden=false;
    alert("ファイルを選択を押してして壁紙を選べ");
}
document.querySelector("#defaultwallpaper").onchange=(e)=>{
    const files=e.target.files;
    for(let idx of files){
        if(String(idx.type).match(/image\//g)){
            const reader = new FileReader();
            reader.onload=(data)=>{
                bg_image=data.target.result;
                document.querySelector("#wallpaper").src=data.target.result;
                document.querySelector("#defaultwallpaper").hidden=true;
                localStorage.setItem("bg-image",bg_image);
            }
            reader.readAsDataURL(idx);
        }
    }
}
document.addEventListener("wheel",(e)=>{
    if(e.deltaY!==0){
        // Settings
        
    }
})
let switchHidden=0;
document.addEventListener("contextmenu",(e)=>{
    e.preventDefault();
    return false;
    document.querySelector("#shortcut").hidden=switchHidden;
    document.querySelector("#search").hidden=switchHidden;
    setTimeout(() => {
        document.querySelector("#shortcut").style.opacity=switchHidden;
        document.querySelector("#search").style.opacity=switchHidden;
    }, 1);
    switchHidden=1-switchHidden;
})
document.querySelector("#search-box").addEventListener("input",(e)=>{
    if(document.querySelector("#search-box").value===''){
        document.querySelector(".placeholder").hidden=false;
    }else{
        document.querySelector(".placeholder").hidden=true;
    }
})
document.querySelector("#search-box").addEventListener("change",(e)=>{
    if(document.querySelector("#search-box").value===''){
        document.querySelector(".placeholder").hidden=false;
    }else{
        document.querySelector(".placeholder").hidden=true;
    }
})
document.querySelector("#search-box").addEventListener("keydown",(e)=>{
    if(e.key==="Enter"){
        window.location.href=`https://google.com/search?q=${document.querySelector("#search-box").value}&l=ja`;
        document.querySelector("#search-box").value="";
    }
})
function transDay(n){
    console.log(n)
    if(n===0){
        return "日";
    }else if(n===1){
        return "月";
    }else if(n===2){
        return "火";
    }else if(n===3){
        return "水";
    }else if(n===4){
        return "木";
    }else if(n===5){
        return "金";
    }else if(n===6){
        return "土";
    }
}