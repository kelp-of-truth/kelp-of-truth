chrome.commands.onCommand.addListener((command) => {
    switch(command){
      case "select_newtabpage":
        console.log("hoge")
        break;
    }
});