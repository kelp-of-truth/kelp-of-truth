
window.addEventListener("load",()=>{
  // scrollTo(0,0);
  document.querySelector(".div1").style.opacity="1";
  // document.querySelectorAll(".header-r nav a")[0].click();
})
window.addEventListener("scroll",()=>{
  // alert(scrollY)
  if(scrollY===0){
    document.body.style.overflow="hidden";
    document.querySelector(".div1 .header-l").style.opacity="1";
  }else{
    document.querySelector(".div1 .header-l").style.opacity="0";
  }
  if(scrollY<window.innerHeight){
    document.querySelector(".div1").style.display="grid";
    document.querySelector("main").style.opacity="0";
    document.querySelector(".header-r nav").style.marginLeft=`${-1*(scrollY*window.outerHeight/document.querySelector(".header-r nav").clientWidth/2)+40}px`;
  }
  if(scrollY>=window.innerHeight){

    document.querySelector(".div1").style.display="none";
    document.body.style.overflow="scroll";
    document.querySelector(".header-r nav").style.marginLeft=`${-1*(scrollY*window.outerHeight/document.querySelector(".header-r nav").clientWidth/2)+40}px`;
    setTimeout(() => {
      document.querySelector("main").style.opacity="1";
    }, 150);
  }
})






particlesJS("particles-js",{
    "particles": {
      "number": {
        "value": 80,
        "density": {
          "enable": true,
          "value_area": 800
        }
      },
      "color": {
        "value": "#000000"
      },
      "shape": {
        "type": "circle",
        "stroke": {
          "width": 0,
          "color": "#000000"
        },
        "polygon": {
          "nb_sides": 5
        },
        "image": {
          "src": "img/github.svg",
          "width": 100,
          "height": 100
        }
      },
      "opacity": {
        "value": 0.5,
        "random": false,
        "anim": {
          "enable": false,
          "speed": 1,
          "opacity_min": 0.1,
          "sync": false
        }
      },
      "size": {
        "value": 3,
        "random": true,
        "anim": {
          "enable": false,
          "speed": 40,
          "size_min": 0.1,
          "sync": false
        }
      },
      "line_linked": {
        "enable": true,
        "distance": 150,
        "color": "#000000",
        "opacity": 0.4,
        "width": 1
      },
      "move": {
        "enable": true,
        "speed": 6,
        "direction": "none",
        "random": false,
        "straight": false,
        "out_mode": "out",
        "bounce": false,
        "attract": {
          "enable": false,
          "rotateX": 600,
          "rotateY": 1200
        }
      }
    },
    "interactivity": {
      "detect_on": "window",
      "events": {
        "onhover": {
          "enable": false,
          "mode": "repulse"
        },
        "onclick": {
          "enable": false,
          "mode": "push"
        },
        "resize": true
      },
      "modes": {
        "grab": {
          "distance": 400,
          "line_linked": {
            "opacity": 1
          }
        },
        "bubble": {
          "distance": 400,
          "size": 40,
          "duration": 2,
          "opacity": 8,
          "speed": 3
        },
        "repulse": {
          "distance": 200,
          "duration": 0.4
        },
        "push": {
          "particles_nb": 4
        },
        "remove": {
          "particles_nb": 2
        }
      }
    },
    "retina_detect": true
})


