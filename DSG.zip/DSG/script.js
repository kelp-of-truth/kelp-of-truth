const canvas=document.querySelector("canvas");
const ctx=canvas.getContext("2d");

let prskey=[];
document.addEventListener("keydown",(e)=>{
    prskey[e.keyCode]=true;
    /**
     * Shift:16
     * Z:90
     * X:88
     * Arrow Left:37
     * Arrow Top:38
     * Arrow Right:39
     * Arrow Bottom:40
     */
    // e.preventDefault();
})
document.addEventListener("keyup",(e)=>{
    prskey[e.keyCode]=false;
    // e.preventDefault();
})

let omae={
    x:282.5,
    y:600
}

class Bullet{
    constructor(name,angle,x,y,age,type){
        this.name=name;
        this.angle=angle;
        this.x=x;
        this.y=y;
        this.age=age;
        this.type=type;
    }
    move(v){
        this.x+=Math.cos(toRad(this.angle))*v;
        this.y-=Math.sin(toRad(this.angle))*v;
    }
}
function toRad(n){
    return n/180*Math.PI;
}


let deg=0;
let bullets=[];
setInterval(() => {
    let randomx=Math.floor(Math.random()*500);
    let randomy=Math.floor(Math.random()*200);
    for(let i=0;i<36;++i){
        bullets.push(new Bullet("test",i*-10,randomx+Math.cos(toRad(i*10))*50,randomy+Math.sin(toRad(i*10))*50,0,"bullet-blue"));
    }
}, 200);
// bullets[0]=new Bullet("test",270,300,100,0,"bullet-red");
setInterval(() => {
    // if(prskey[37]&&prskey[38]){
    //     if(prskey[16]){
    //         omae.x-=1/(Math.sqrt(2));
    //         omae.y-=1/(Math.sqrt(2));
    //     }else{
    //         omae.x-=2/(Math.sqrt(2));
    //         omae.y-=2/(Math.sqrt(2));
    //     }
    // }else if(prskey[38]&&prskey[39]){
    //     if(prskey[16]){
    //         omae.x+=1/(Math.sqrt(2));
    //         omae.y-=1/(Math.sqrt(2));
    //     }else{
    //         omae.x+=2/(Math.sqrt(2));
    //         omae.y-=2/(Math.sqrt(2));
    //     }
    // }else if(prskey[39]&&prskey[40]){
    //     if(prskey[16]){
    //         omae.x+=1/(Math.sqrt(2));
    //         omae.y+=1/(Math.sqrt(2));
    //     }else{
    //         omae.x+=2/(Math.sqrt(2));
    //         omae.y+=2/(Math.sqrt(2));
    //     }
    // }else if(prskey[40]&&prskey[37]){
    //     if(prskey[16]){
    //         omae.x-=1/(Math.sqrt(2));
    //         omae.y+=1/(Math.sqrt(2));
    //     }else{
    //         omae.x-=2/(Math.sqrt(2));
    //         omae.y+=2/(Math.sqrt(2));
    //     }
    // }else if(prskey[37]){
    //     if(prskey[16]){
    //         omae.x-=1;
    //     }else{
    //         omae.x-=2;
    //     }
    // }else if(prskey[38]){
    //     if(prskey[16]){
    //         omae.y-=1;
    //     }else{
    //         omae.y-=2;
    //     }
    // }else if(prskey[39]){
    //     if(prskey[16]){
    //         omae.x+=1;
    //     }else{
    //         omae.x+=2;
    //     }
    // }else if(prskey[40]){
    //     if(prskey[16]){
    //         omae.y+=1;
    //     }else{
    //         omae.y+=2;
    //     }
    // }

    var mx=0;
    var my=0;
    if(prskey[37]){
        mx=-0.5;
    }
    if(prskey[38]){
        my=-0.5;
    }
    if(prskey[39]){
        mx=0.5;
    }
    if(prskey[40]){
        my=0.5;
    }
    // console.log(mx/Math.sqrt(mx^2+my^2))
    // console.log(mx,my)
    if(mx!==0||my!==0){
        mx=mx/Math.hypot(mx,my);
        my=my/Math.hypot(mx,my);
        if(!prskey[16]){
            mx=mx*1.6;
            my=my*1.6;
        }
        if(omae.x+mx<0){
            omae.x=0;
        }else if(omae.x+mx>565){
            omae.x=565;
        }else{
            omae.x+=mx;
        }
        if(omae.y+my<0){
            omae.y=0;
        }else if(omae.y+my>665){
            omae.y=665;
        }else{
            omae.y+=my;
        }
    }

    
    wp.src="./wp.png";
    ctx.clearRect(0,0,1080,720);
    ctx.drawImage(wp,omae.x,omae.y);

    for(let i=0;i<bullets.length;i++){
        var idx=bullets[i];
        bltImg.src=`./bullet/${idx.type}.png`;
        ctx.drawImage(bltImg,idx.x,idx.y);
        idx.move(1);
        if(idx.x<-20||idx.x>580||idx.y<-20||idx.y>700){
            bullets.splice(i,1);
        }
        idx.age++;
    }

}, 5);
const wp=new Image(20,20);
const bltImg=new Image();